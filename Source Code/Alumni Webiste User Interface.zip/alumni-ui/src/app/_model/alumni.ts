export class Alumni{
    
        alumniId: Number;
        alumniName: String;
        alumniEmail:String;
        alumniWorkPlace:String; 
        address: String;
        contactPhoneNumber:Number;
        priorWorkPlace: String;
        industry: String;
        experience: String;
        graduationYear: Number;
    
}