export class AlumniRequests{
    
        firstName: String;
        lastName: String;
        email: String;
        password:String;
        addressLine1: String;
        addressLine2: String;
        city: String;
        state: String;
        zipcode: String;
        contact:Number;
        currentWork: String;
        previousWork: String;
        industry: String;
        experience: String;
        graduationYear: String;
    
}