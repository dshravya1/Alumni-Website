export class Student{
    
    studentId: Number;
    department: String;
    year:String;
    creditstilldate:String; 
    degree: String;
    gpa:Number;
    stream: String;
    email: String;
    studentName: String;
    address: Number;
    contactNumber: Number;

}