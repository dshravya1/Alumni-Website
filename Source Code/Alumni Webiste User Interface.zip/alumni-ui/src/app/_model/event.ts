export class Events {
    eventId: Number;
    eventName: String;
    eventDescription: String;
    enrolledByTheUser: boolean;
}