export class Club {
    clubId: Number;
    clubName: String;
    clubDescription: String;
    enrolledByTheUser: boolean;
}