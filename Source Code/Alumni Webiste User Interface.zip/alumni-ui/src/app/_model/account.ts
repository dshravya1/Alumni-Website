export class Account{
    accountType:Number    
    email:String 
    password:String
    userId:Number
}