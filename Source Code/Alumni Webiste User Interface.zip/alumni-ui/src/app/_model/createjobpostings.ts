export class CreateJobPostings{

    jobName: String;
    jobDescription: String;
    company: String;
    contactNumber: Number;
    website: String;
    publisher: Number;
}
