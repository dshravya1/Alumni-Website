export class CreateClub {
    clubName: String;
    clubDescription: String;
    clubLeader: Number;
    createdBy: Number;
}