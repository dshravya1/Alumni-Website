export class Alumnis{
    
    alumniId: Number;
    alumniName: String;
    alumniEmail:String;
    alumniWorkPlace:String; 
    address: String;
    contactPhoneNumber:Number;
    priorWorkPlace: String;
    industry: String;
    experience: String;
    graduationYear: Number;
    followedByUser:boolean;

}