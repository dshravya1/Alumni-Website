import { Student } from './student';
import { Alumni } from './alumni';

export class Register{
    
    studentDet: Student;
    alumniDet: Alumni;

}