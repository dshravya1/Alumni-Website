export class Admin{
    
    adminId: Number;
    email: String;
    adminName: String;
    address: Number;
    contactNumber: Number;

}