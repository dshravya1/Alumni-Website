import { Component, OnInit } from '@angular/core';
import { Admin } from 'src/app/_model/admin';
import { AllService } from 'src/app/_service/all.service';

@Component({
  selector: 'app-adminprofile',
  templateUrl: './adminprofile.component.html',
  styleUrls: ['./adminprofile.component.css']
})
export class AdminprofileComponent implements OnInit {
  admin:Admin;
  constructor(private allService:AllService) { }

  ngOnInit() {
    this.allService.getAdminDetails().subscribe(res => {
      this.admin = res as Admin;
    });
  }
}
