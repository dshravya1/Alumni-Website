import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/_model/student';
import { AllService } from 'src/app/_service/all.service';

@Component({
  selector: 'app-studentprofile',
  templateUrl: './studentprofile.component.html',
  styleUrls: ['./studentprofile.component.css']
})
export class StudentprofileComponent implements OnInit {
  student:Student;
  constructor(private allService:AllService) { }

  ngOnInit() {
    this.allService.getStudentDetails().subscribe(res => {
      this.student = res as Student;
    });
  }

}
