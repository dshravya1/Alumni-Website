
import { Component, OnInit } from '@angular/core';
import { AllService } from '../../_service/all.service';
import { FormGroup, FormControl, FormGroupDirective, NgForm, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { ErrorStateMatcher } from '@angular/material/core';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})


export class RegisterComponent{

  loading: boolean;
  returnUrl: any;

  constructor(private allService: AllService, private router: Router, private route: ActivatedRoute) { }
  // myForm: FormGroup;
  // matcher = new MyErrorStateMatcher();

  alumniForm = new FormGroup({
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('',[Validators.required]),
    email: new FormControl('',[Validators.required, Validators.email]),
    password: new FormControl('',[Validators.required, Validators.min(6)]),
    addressLine1: new FormControl('',[Validators.required]),
    addressLine2: new FormControl('',[Validators.required]),
    city: new FormControl('',[Validators.required]),
    state: new FormControl('',[Validators.required]),
    zipcode: new FormControl('',[Validators.required]),
    contact: new FormControl('',[Validators.required]),
    currentWork: new FormControl('',[Validators.required]),
    previousWork: new FormControl('',[Validators.required]),
    industry: new FormControl('',[Validators.required]),
    experience: new FormControl('',[Validators.required]),
    graduationYear: new FormControl('',[Validators.required])
  });

  studentForm = new FormGroup({
      firstName: new FormControl('',[Validators.required]),
      lastName: new FormControl('',[Validators.required]),
      email: new FormControl('',[Validators.required, Validators.email]),
      password: new FormControl('',[Validators.required]),
      addressLine1: new FormControl('',[Validators.required]),
      addressLine2: new FormControl('',[Validators.required]),
      city: new FormControl('',[Validators.required]),
      state: new FormControl('',[Validators.required]),
      zipcode: new FormControl('',[Validators.required]),
      contact: new FormControl('',[Validators.required]),
      department: new FormControl('',[Validators.required]),
      stream: new FormControl('',[Validators.required]),
      degree: new FormControl('',[Validators.required]),
      gpa: new FormControl('',[Validators.required]),
      creditsTillDate: new FormControl('',[Validators.required]),
      currentYear: new FormControl('',[Validators.required])
  });
  
  email = new FormControl('', [Validators.required, Validators.email]);
  password = new FormControl('', [Validators.required]);
  confirmPassword = new FormControl('', [Validators.required]);
  

registerAlumni(alumniFormValue: FormGroup) {
  this.loading = true;
  this.allService.registerAlumni({
    firstName: alumniFormValue.value.firstName,
    lastName: alumniFormValue.value.lastName,
    email: alumniFormValue.value.email,
    password: alumniFormValue.value.password,
    addressLine1: alumniFormValue.value.addressLine1,
    addressLine2: alumniFormValue.value.addressLine2,
    city: alumniFormValue.value.city,
    state: alumniFormValue.value.state,
    zipcode: alumniFormValue.value.zipcode,
    contact: alumniFormValue.value.contact,
    currentWork: alumniFormValue.value.currentWork,
    previousWork: alumniFormValue.value.previousWork,
    industry: alumniFormValue.value.industry,
    experience: alumniFormValue.value.experience,
    graduationYear: alumniFormValue.value.graduationYear
  }) .pipe(first())
  .subscribe(
      data => {
          this.router.navigate(['/directory']);
      },
      error => {
      this.alumniForm.reset();
          this.loading = false;
      });
}

  registerStudent(studentFormValue: FormGroup) {
    this.loading = true;
    this.allService.registerStudent({
    firstName: studentFormValue.value.firstName,
    lastName: studentFormValue.value.lastName,
    email: studentFormValue.value.email,
    password: studentFormValue.value.password,
    addressLine1: studentFormValue.value.addressLine1,
    addressLine2: studentFormValue.value.addressLine2,
    city: studentFormValue.value.city,
    state: studentFormValue.value.state,
    zipcode: studentFormValue.value.zipcode,
    contact: studentFormValue.value.contact,
    department: studentFormValue.value.department,
    stream: studentFormValue.value.stream,
    degree: studentFormValue.value.degree,
    gpa: studentFormValue.value.gpa,
    creditsTillDate: studentFormValue.value.creditsTillDate,
    currentYear: studentFormValue.value.currentYear
    }) .pipe(first())
    .subscribe(
        data => {
            this.router.navigate(['/directory']);
        },
        error => {
        this.alumniForm.reset();
            this.loading = false;
        });
}

  getErrorMessage() {
    if (this.email.hasError('required')) {
      return '';
    }

    return this.email.hasError('email') ? 'Not a valid email' : '';
  }

}