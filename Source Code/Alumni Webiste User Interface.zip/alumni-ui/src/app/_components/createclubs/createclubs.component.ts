import { Component, OnInit} from '@angular/core';
import { AllService } from 'src/app/_service/all.service';
import { FormGroup, FormControl, FormGroupDirective, NgForm, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-createclubs',
  templateUrl: './createclubs.component.html',
  styleUrls: ['./createclubs.component.css']
})
export class CreateClubsComponent {

  loading: boolean;
  returnUrl: any;

  constructor(private allService: AllService, private router: Router, private route: ActivatedRoute) { }  

  clubForm = new FormGroup({
    clubName: new FormControl('',[Validators.required]),
    clubDescription: new FormControl('',[Validators.required])
    // company: new FormControl('',[Validators.required]),
    // contactNumber: new FormControl('',[Validators.required]),
    // website: new FormControl('',[Validators.required]),
    // publisher: new FormControl('',[Validators.required])    
  });
  
  createClub(clubFormValue: FormGroup) {
    this.loading = true;
    this.allService.createClub({
      clubName: clubFormValue.value.clubName,
      clubDescription: clubFormValue.value.clubDescription
    }) .pipe(first())
    .subscribe(
        data => {
            this.router.navigate(['/directory']);
        },
        error => {
        this.clubForm.reset();
            this.loading = false;
        });
  }
}
