import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { Club } from 'src/app/_model/club';
import { MatTableDataSource, MatTable, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { AllService } from 'src/app/_service/all.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-clubs',
  templateUrl: './clubs.component.html',
  styleUrls: ['./clubs.component.css']
})
export class ClubsComponent implements OnInit {
  displayedColumns = ['clubName','clubDescription','join'];
  public dataSource = new MatTableDataSource<Club>();

  @ViewChild(MatTable, { static: true }) table: MatTable<any>;
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  constructor(private allService: AllService, private dialog: MatDialog, ) {
  }
  
  ngOnInit() {
    
this.getAllClubs();
  }
  getAllClubs(): void{
    this.allService.getAllClubs()
    .subscribe(res => {
      this.dataSource.data = res as Club[];
    });
  }
  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }
  join(clickevent) {
    console.log(clickevent)
    this.allService.postClubMembers(clickevent.clubId)
    .pipe(first())
    .subscribe(
        data => {
          this.getAllClubs();
        },
        error => {
        
        });
  }
}
