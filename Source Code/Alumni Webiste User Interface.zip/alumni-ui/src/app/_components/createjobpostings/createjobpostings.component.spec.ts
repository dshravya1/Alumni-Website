import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateJobPostingsComponent } from './createjobpostings.component';

describe('CreateJobPostingsComponent', () => {
  let component: CreateJobPostingsComponent;
  // let fixture: ComponentFixture<CreateJobPostingsComponent>;

  // beforeEach(async(() => {
  //   TestBed.configureTestingModule({
  //     declarations: [ CreateJobPostingsComponent ]
  //   })
  //   .compileComponents();
  // }));

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(CreateJobPostingsComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
