import { Component, OnInit} from '@angular/core';
import { AllService } from 'src/app/_service/all.service';
import { FormGroup, FormControl, FormGroupDirective, NgForm, Validators, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-createjobpostings',
  templateUrl: './createjobpostings.component.html',
  styleUrls: ['./createjobpostings.component.css']
})
export class CreateJobPostingsComponent {

  loading: boolean;
  returnUrl: any;

  constructor(private allService: AllService, private router: Router, private route: ActivatedRoute) { }  

  jobForm = new FormGroup({
    jobName: new FormControl('',[Validators.required]),
    jobDescription: new FormControl('',[Validators.required]),
    company: new FormControl('',[Validators.required]),
    contactNumber: new FormControl('',[Validators.required]),
    website: new FormControl('',[Validators.required]),
    publisher: new FormControl('',[Validators.required])    
  });
  
  createJob(jobFormValue: FormGroup) {
    this.loading = true;
    this.allService.createJob({
      jobName: jobFormValue.value.jobName,
      jobDescription: jobFormValue.value.jobDescription,
      company: jobFormValue.value.company,
      contactNumber: jobFormValue.value.contactNumber,
      website: jobFormValue.value.website,
      publisher: jobFormValue.value.publisher,
    }) .pipe(first())
    .subscribe(
        data => {
            this.router.navigate(['/jobpostings']);
        },
        error => {
        this.jobForm.reset();
            this.loading = false;
        });
  }
}
