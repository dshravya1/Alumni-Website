import { Injectable } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { HttpClient } from '@angular/common/http'
import { Observable, of, from} from 'rxjs';
import { map } from 'rxjs/operators';
import { Alumni } from '../_model/alumni';
import { JobPostings } from '../_model/jobpostings';
import { CreateJobPostings } from '../_model/createjobpostings';
import { Events } from '../_model/event';
import { Alumnis } from '../_model/alumnis';
import { Student } from '../_model/student';
import { Admin } from '../_model/admin';
import { Account } from '../_model/account';
import { Register } from '../_model/register';
import { AlumniRequests } from '../_model/alumniRequest';
import { Club } from '../_model/club';
import { CreateClub } from '../_model/createclub';


@Injectable()
export class AllService {
    constructor(private http: HttpClient) { }
    loginStatus: boolean = false;
    user: Account;
    alumni: AlumniRequests;
    student: Student;
    jobPosting: JobPostings;
    createjobpostings: CreateJobPostings;
    createclub: CreateClub;
    requestOk: any;
    private options = { headers: new HttpHeaders().append('Content-Type', 'application/json') };

    login(user: { email: string, password: string }): Observable<void> {
        console.log('inside login');
        return this.http.post<any>(`http://localhost:8080/authenticate/login`, user, this.options).pipe(map((response: Response) => {
            this.loginStatus = true;
            this.user = response['user'];
        }));
    }  

    logout(){
      this.loginStatus = false;
    } 

    registerStudent(student:{firstName: String,lastName: String,email: String,password:String,addressLine1: String,addressLine2: String,city: String,state: String, zipcode: String,contact:Number, department: String,  stream: String, degree: String, gpa: String, creditsTillDate: String, currentYear: String}){
      console.log('inside register Student');
      return this.http.post<any>(`http://localhost:8080/authenticate/registerStudent`, student, this.options).pipe(map((response: Response) => {
        this.loginStatus = true;
        this.user = response['user'];
    }));
    }

    registerAlumni(alumni:{firstName: String,lastName: String,email: String,password:String,addressLine1: String,addressLine2: String,city: String,state: String, zipcode: String,contact:Number, currentWork: String, previousWork: String, industry: String, experience: String, graduationYear: String}): Observable<void>{
      console.log('inside register Alumni');
      return this.http.post<any>(`http://localhost:8080/authenticate/registerAlumni`, alumni, this.options).pipe(map((response: Response) => {
            this.loginStatus = true;
            this.user = response['user'];
        }));
    } 

    getAllAlumni(): Observable<Alumnis[]> {
        const getAllUrl = `http://localhost:8080/alumni/getAllAlumni/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Alumnis[]));
      }
      getUserDetails(): Observable<Alumni> { 
        const getAllUrl = `http://localhost:8080/alumni/getAlumniDetail/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Alumni));
      
      }
      getStudentDetails(): Observable<Student> { 
        const getAllUrl = `http://localhost:8080/alumni/getStudentDetail/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Student));
      
      }
      getAdminDetails(): Observable<Admin> { 
        const getAllUrl = `http://localhost:8080/alumni/getAdminDetail/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Admin));
      
      }
      getAllJobpostings(): Observable<JobPostings[]> {
        const getAllUrl = `http://localhost:8080/alumni/getAllJobPostings`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as JobPostings[]));
      }
      getAllEvents(): Observable<Events[]>{
        const getAllUrl = `http://localhost:8080/alumni/getEventsEnrollmentForAUser/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Events[]));
      }
      postParticipant(eventId:Number): Observable<void>{
        return this.http.post<any>(`http://localhost:8080/alumni/createEventEnrollmentForAUser`, {eventId:eventId, userId:this.user.userId}, this.options).pipe(map((response: Response) => {
      }));
      }
      postFollow(followingId:Number): Observable<void>{
        return this.http.post<any>(`http://localhost:8080/alumni/createFollowerForAUser`, {followerId:this.user.userId, followingId:followingId}, this.options).pipe(map((response: Response) => {
      }));
      }
      postDeleteUser(alumniId:Number): Observable<void>{
        return this.http.delete<any>(`http://localhost:8080/alumni/deleteUser${alumniId}`, this.options).pipe(map((response: Response) => {
          this.requestOk = true;
      }));
      }
      getAllClubs(): Observable<Club[]>{
        const getAllUrl = `http://localhost:8080/alumni/getClubsEnrollmentForAUser/${this.user.userId}`;
        return this.http.get(getAllUrl,this.options).pipe(map(response => response as Club[]));
      }
      postClubMembers(clubId:Number): Observable<void>{
        return this.http.post<any>(`http://localhost:8080/alumni/createClubEnrollmentForAUser`, {clubId:clubId, alumniId:this.user.userId}, this.options).pipe(map((response: Response) => {
      }));
      }

      createClub(createclub:{clubName: string, clubDescription: string}): Observable<void> {
        console.log('inside create club');
        return this.http.post<any>(`http://localhost:8080/alumni/createNewClub`, {createclub,clubLeader:this.user.userId}, this.options).pipe(map((response: Response) => {
            this.loginStatus = true;
            // this.user = response['user'];
        }));
    } 
      
      createJob(createjobpostings: { jobName: string, jobDescription: string, company: string, contactNumber: string, website: string, publisher: string }): Observable<void> {
        console.log('inside job posting');
        return this.http.post<any>(`http://localhost:8080/alumni/createJobPosting`, createjobpostings, this.options).pipe(map((response: Response) => {
            this.loginStatus = true;
            // this.user = response['user'];
        }));
    }  
}