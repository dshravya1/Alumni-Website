package edu.ms.uncc.alumni.model;

import org.hibernate.annotations.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class StudentObject {


    @Id
    @Column(name = "Student_id")
    private int studentId;

    @Column(name = "Department")
    private String department;

    @Column(name = "Year")
    private int year;

    @Column(name = "Credits_till_date")
    private int creditsTillDate;

    @Column(name = "GPA")
    private float gpa;

    @Column(name = "Stream")
    private String stream;

    @Column(name = "Degree")
    private String degree;


    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getCreditsTillDate() {
        return creditsTillDate;
    }

    public void setCreditsTillDate(int creditsTillDate) {
        this.creditsTillDate = creditsTillDate;
    }

    public float getGpa() {
        return gpa;
    }

    public void setGpa(float gpa) {
        this.gpa = gpa;
    }

    public String getStream() {
        return stream;
    }

    public void setStream(String stream) {
        this.stream = stream;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public StudentObject(int studentId, String department, int year, int creditsTillDate, float gpa, String stream, String degree) {
        this.studentId = studentId;
        this.department = department;
        this.year = year;
        this.creditsTillDate = creditsTillDate;
        this.gpa = gpa;
        this.stream = stream;
        this.degree = degree;
    }

    public StudentObject() {
    }
}
