package edu.ms.uncc.alumni.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

@Entity
@Immutable
@Table(name = "Student_view")

public class Student {
		
		@Id
		@Column(name = "Student_id")
		private int studentId;
		
		@Column(name = "Department")
		private String department;
		
		@Column(name = "Year")
		private String year;
		
		@Column(name = "Credits_till_date")
		private String creditstilldate;
		
		@Column(name = "Degree")
		private String degree;
		
		@Column(name = "GPA")
		private String gpa;
		
		@Column(name = "Stream")
		private String stream;
		
		@Column(name = "Email_id")
		private String email;
		
		@Column(name = "Student_name")
		private String studentName;
		
		@Column(name = "Address")
		private String address;
		
		@Column(name = "Contact_number")
		private String contactNumber;

		public int getStudentId() {
			return studentId;
		}

		public void setStudentId(int studentId) {
			this.studentId = studentId;
		}

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		public String getYear() {
			return year;
		}

		public void setYear(String year) {
			this.year = year;
		}

		public String getCreditstilldate() {
			return creditstilldate;
		}

		public void setCreditstilldate(String creditstilldate) {
			this.creditstilldate = creditstilldate;
		}

		public String getDegree() {
			return degree;
		}

		public void setDegree(String degree) {
			this.degree = degree;
		}

		public String getGpa() {
			return gpa;
		}

		public void setGpa(String gpa) {
			this.gpa = gpa;
		}

		public String getStream() {
			return stream;
		}

		public void setStream(String stream) {
			this.stream = stream;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getStudentName() {
			return studentName;
		}

		public void setStudentName(String studentName) {
			this.studentName = studentName;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getContactNumber() {
			return contactNumber;
		}

		public void setContactNumber(String contactNumber) {
			this.contactNumber = contactNumber;
		}

}
