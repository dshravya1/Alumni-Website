package edu.ms.uncc.alumni.model;

import javax.persistence.*;

@Entity
@Table(name = "Clubs")
public class Club {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Club_id")
	private int clubId;

	@Column(name = "Club_Name")
	private String clubName;

	@Column(name = "Club_Description")
	private String clubDescription;

	@Column(name = "Club_Leader")
	private int clubLeader;

	@Column(name = "Created_by")
	private int createdBy;

	public int getClubId() {
		return clubId;
	}

	public void setClubId(int clubId) {
		this.clubId = clubId;
	}

	public String getClubName() {
		return clubName;
	}

	public void setClubName(String clubName) {
		this.clubName = clubName;
	}

	public String getClubDescription() {
		return clubDescription;
	}

	public void setClubDescription(String clubDescription) {
		this.clubDescription = clubDescription;
	}

	public int getClubLeader() {
		return clubLeader;
	}

	public Club() {
		super();
	}

	public Club(String clubName, String clubDescription, int clubLeader, int createdBy) {
		this.clubName = clubName;
		this.clubDescription = clubDescription;
		this.clubLeader = clubLeader;
		this.createdBy = createdBy;
	}

	public void setClubLeader(int clubLeader) {
		this.clubLeader = clubLeader;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


}