package edu.ms.uncc.alumni.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import edu.ms.uncc.alumni.model.ClubMembers;

@Repository
public interface ClubMemberRepository extends JpaRepository<ClubMembers, Integer> {
	
	@Query(value = "select * from Club_Members where Alumni_id = ?1" , nativeQuery = true)
    public List<ClubMembers> findByUserId(@Param("Alumni_id") int userId);

	@Transactional
	@Modifying
	@Query(value = "insert into Club_Members values (?,?)", nativeQuery = true)
    public int saveClubMember(@Param("Club_id") int eventId, @Param("Alumni_id") int userId);
}
