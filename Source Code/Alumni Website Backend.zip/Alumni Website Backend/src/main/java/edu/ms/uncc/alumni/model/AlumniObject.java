package edu.ms.uncc.alumni.model;

import javax.persistence.*;

@Entity
@Table(name = "Alumni")
public class AlumniObject {


        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name = "Alumni_id")
        private int alumniid;

        @Column(name = "Current_work_place")
        private String currentworkplace;

        @Column(name = "Prior_work_place")
        private String priorworkplace;

        @Column(name = "Industry")
        private String industry;

        @Column(name = "Experience")
        private String experience;

        @Column(name = "Graduation_year")
        private int graduationyear;

        public AlumniObject(int alumniid, String currentworkplace, String priorworkplace, String industry, String experience, int graduationyear) {
                this.alumniid = alumniid;
                this.currentworkplace = currentworkplace;
                this.priorworkplace = priorworkplace;
                this.industry = industry;
                this.experience = experience;
                this.graduationyear = graduationyear;
        }

        public AlumniObject() {
        }

        public int getAlumniid() {
                return alumniid;
        }

        public void setAlumniid(int alumniid) {
                this.alumniid = alumniid;
        }

        public String getCurrentworkplace() {
                return currentworkplace;
        }

        public void setCurrentworkplace(String currentworkplace) {
                this.currentworkplace = currentworkplace;
        }

        public String getPriorworkplace() {
                return priorworkplace;
        }

        public void setPriorworkplace(String priorworkplace) {
                this.priorworkplace = priorworkplace;
        }

        public String getIndustry() {
                return industry;
        }

        public void setIndustry(String industry) {
                this.industry = industry;
        }

        public String getExperience() {
                return experience;
        }

        public void setExperience(String experience) {
                this.experience = experience;
        }

        public int getGraduationyear() {
                return graduationyear;
        }

        public void setGraduationyear(int graduationyear) {
                this.graduationyear = graduationyear;
        }
}
