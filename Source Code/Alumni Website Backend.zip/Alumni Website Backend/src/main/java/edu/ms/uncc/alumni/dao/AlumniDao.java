package edu.ms.uncc.alumni.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import edu.ms.uncc.alumni.model.*;
import edu.ms.uncc.alumni.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class AlumniDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(AlumniDao.class);
	
	@Autowired
	private AlumniRepository alumniRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	private JobPostingRepository jobPostingRepository;
	
	@Autowired
	private EventRepository eventRepository;
	
	@Autowired
	private ParticipantRepository participantRepository;
	
	@Autowired
	private FollowRepository followRepository;

	@Autowired
	private AlumniObjectRepository alumniObjectRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private StudentObjectRepository studentObjectRepository;

	@Autowired
	private ClubRepository clubRepository;

	@Autowired
	private ClubMemberRepository clubMemberRepository;
	
	public List<Alumni> getAllAlumniExcludingCurrentUser(int userId){
		LOGGER.info("Retrieving Alumni from View");
		List<Alumni> listOfAlumnus = new ArrayList<>();
		alumniRepository.findByAlumniIdNotQuery(userId).forEach(listOfAlumnus :: add);
		return listOfAlumnus;
	}
	
	public Alumni getSpecificAlumniDetails(int userId){
		LOGGER.info("Retrieving Alumni Details for a specific user");
		return alumniRepository.findOne(userId);
	}
	
	public Student getSpecificStudentDetails(int userId){
		LOGGER.info("Retrieving Student Details for a specific user");
		return studentRepository.findOne(userId);
	}
	
	public Admin getSpecificAdminDetails(int userId){
		LOGGER.info("Retrieving Admin Details for a specific user");
		return adminRepository.findOne(userId);
	}
	
	public List<JobPosting> getAllJobPostings(){
		LOGGER.info("Getting all Job postings posted in the system");
		return jobPostingRepository.findAll();
	}
	
	public JobPosting createJobPosting(JobPosting jobPosting) {
		return jobPostingRepository.save(jobPosting);
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<List<Event>> getAllEvents(){
		return CompletableFuture.completedFuture(eventRepository.findAll());
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<List<Participant> >getEventsForAParticipant(int userId){
		return CompletableFuture.completedFuture(participantRepository.findByUserId(userId));
	}
	
	public int createEventEnrollment(Participant participant) {
		return participantRepository.saveParticipant(participant.getEventId(), participant.getUserId());
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<List<Club>> getAllClubs(){
		return CompletableFuture.completedFuture(clubRepository.findAll());
	}
	
	@Async("asyncExecutor")
	public CompletableFuture<List<ClubMembers>> getClubForAMember(int userId){
		return CompletableFuture.completedFuture(clubMemberRepository.findByUserId(userId));
	}
	public int createClubEnrollment(ClubMembers clubMembers) {
		return clubMemberRepository.saveClubMember(clubMembers.getClubId(), clubMembers.getAlumniId());
	}
	public List<Follow> getAllFollowersForAUser(int userId){
		return followRepository.findByUserId(userId);
	}
	
	public int createFollower(Follow follow) {
		return followRepository.saveFollower(follow.getFollowerId(), follow.getFollowingId());
	}
	public boolean deleteAlumniEntity(int userID) {

		Alumni alumni = alumniRepository.findOne(userID);

		if(studentObjectRepository.findOne(userID)!=null){
			studentObjectRepository.delete(userID);
			studentObjectRepository.flush();
		}else{
			alumniObjectRepository.delete(userID);
			alumniObjectRepository.flush();
		}

		accountRepository.delete(alumni.getAlumniEmail());
		accountRepository.flush();

		userRepository.delete(userID);
		userRepository.flush();

		while (followRepository.findByUserId(userID)!=null) {
			followRepository.delete(userID);
			followRepository.flush();
		}



		return userRepository.exists(userID);

	}

	public Club createNewClub(Club club) {
		return clubRepository.saveAndFlush(club);
	}

}
