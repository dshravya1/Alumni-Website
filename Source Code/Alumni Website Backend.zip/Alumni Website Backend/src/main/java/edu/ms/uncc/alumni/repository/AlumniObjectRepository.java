package edu.ms.uncc.alumni.repository;



import edu.ms.uncc.alumni.model.AlumniObject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface AlumniObjectRepository extends JpaRepository<AlumniObject,Integer> {

}
