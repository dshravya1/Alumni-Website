package edu.ms.uncc.alumni.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import edu.ms.uncc.alumni.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ms.uncc.alumni.dao.AlumniDao;

@Service
public class AlumniService {

	@Autowired
	private AlumniDao alumniDao;

	public List<AlumniModel> getAllAlumniExcludingCurrentUser(int userId)
			throws InterruptedException, ExecutionException {

		List<Alumni> alumniList = alumniDao.getAllAlumniExcludingCurrentUser(userId);
		List<Follow> followerList = alumniDao.getAllFollowersForAUser(userId);
		List<AlumniModel> list = new ArrayList<>();

		for (Alumni alumnus : alumniList) {
			list.add(new AlumniModel(alumnus));
		}

		for (Follow follow : followerList) {
			for (AlumniModel alumnus : list) {
				if (alumnus.getAlumniId() == follow.getFollowingId()) {
					alumnus.setFollowedByUser(true);
				}
			}
		}

		return list;
	}

	public Alumni getSpecificAlumniDetail(int userId) {
		return alumniDao.getSpecificAlumniDetails(userId);
	}
	
	public Student getSpecificStudentDetail(int userId) {
		return alumniDao.getSpecificStudentDetails(userId);
	}
	
	public Admin getSpecificAdminDetail(int userId) {
		return alumniDao.getSpecificAdminDetails(userId);
	}

	public List<JobPosting> getAllJobPostings() {
		return alumniDao.getAllJobPostings();
	}

	public JobPosting createJobPosting(JobPosting jobPosting) {
		return alumniDao.createJobPosting(jobPosting);
	}

	public List<EventModel> getAllEventsAndEnrollmentForAUser(int userId)
			throws InterruptedException, ExecutionException {
		CompletableFuture<List<Event>> events = alumniDao.getAllEvents();
		CompletableFuture<List<Participant>> participantEvents = alumniDao.getEventsForAParticipant(userId);
		CompletableFuture.allOf(events, participantEvents).join();
		List<Event> listOfEvents = events.get();
		List<Participant> listOfParticipants = participantEvents.get();
		List<EventModel> eventModelsList = new ArrayList<>();
		for (Event event : listOfEvents) {
			eventModelsList.add(new EventModel(event));
		}
		for (Participant participant : listOfParticipants) {
			for (EventModel eventModel : eventModelsList) {
				if (participant.getEventId() == eventModel.getEventId()) {
					eventModel.setEnrolledByTheUser(true);
				}
			}
		}
		return eventModelsList;
	}

	public int createClubEnrollment(ClubMembers clubMembers) {
		return alumniDao.createClubEnrollment(clubMembers);
	}
	public List<ClubModel> getAllClubsAndEnrollmentForAUser(int userId) throws InterruptedException, ExecutionException {
		CompletableFuture<List<Club>> clubs = alumniDao.getAllClubs();
		
		CompletableFuture<List<ClubMembers>> clubMembersClub = alumniDao.getClubForAMember(userId);
		
		CompletableFuture.allOf(clubs, clubMembersClub).join();
		
		List<Club> listOfClubs = clubs.get();
		List<ClubMembers> listOfClubMembers = clubMembersClub.get();
		List<ClubModel> clubModelsList = new ArrayList<>();
		for (Club club : listOfClubs) {
			clubModelsList.add(new ClubModel(club));
		}
		
		System.out.println(clubModelsList.size());
		
		for (ClubMembers clubMembers : listOfClubMembers) {
			for (ClubModel clubModel : clubModelsList) {
				if (clubMembers.getClubId() == clubModel.getClubId()) {
					clubModel.setEnrolledByTheUser(true);
				}
			}
		}
		return clubModelsList;
	}
	public int createEventEnrollment(Participant participant) {
		return alumniDao.createEventEnrollment(participant);
	}

	/*public int createClubEnrollment(ClubMembers clubMembers) {
		return alumniDao.createClubEnrollment(clubMembers);
	}*/

	public int createFollowing(Follow follow) {
		return alumniDao.createFollower(follow);
	}

	public boolean deleteAlumniEntity(int userId) {
		return alumniDao.deleteAlumniEntity(userId);
	}

	public Club createNewClub(Club club) {
		return alumniDao.createNewClub(club);
	}

}
