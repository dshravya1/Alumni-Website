package edu.ms.uncc.alumni.model;

import javax.persistence.*;

@Entity
@Table(name = "Club_Members")
public class ClubMembers{
	
	@Id
	@Column(name = "Club_id")
	private int clubId;
	
	
	@Column(name = "Alumni_id")
	private int alumniId;

	public int getClubId() {
		return clubId;
	}

	public void setClubId(int clubId) {
		this.clubId = clubId;
	}

	public int getAlumniId() {
		return alumniId;
	}

	public void setAlumniId(int alumniId) {
		this.alumniId = alumniId;
	}
}