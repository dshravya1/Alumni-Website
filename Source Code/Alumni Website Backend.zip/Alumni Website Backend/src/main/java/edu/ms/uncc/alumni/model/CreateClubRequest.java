package edu.ms.uncc.alumni.model;

public class CreateClubRequest {

    Club createclub;
    int clubLeader;

    public Club getCreateclub() {
        return createclub;
    }

    public void setCreateclub(Club createclub) {
        this.createclub = createclub;
    }

    public int getClubLeader() {
        return clubLeader;
    }

    public void setClubLeader(int clubLeader) {
        this.clubLeader = clubLeader;
    }


}
