package edu.ms.uncc.alumni.repository;

import edu.ms.uncc.alumni.model.Student;
import edu.ms.uncc.alumni.model.StudentObject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StudentObjectRepository extends JpaRepository<StudentObject,Integer> {

}
