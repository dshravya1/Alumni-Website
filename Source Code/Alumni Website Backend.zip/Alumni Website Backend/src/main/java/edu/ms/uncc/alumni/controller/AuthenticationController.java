package edu.ms.uncc.alumni.controller;

import edu.ms.uncc.alumni.model.*;
import edu.ms.uncc.alumni.service.AlumniService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import edu.ms.uncc.alumni.service.AuthenticationService;

@RestController
@RequestMapping("/authenticate")
public class AuthenticationController {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationController.class);

	@Autowired
	private AuthenticationService authenticationService;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationTokenAndLogin(@RequestBody AuthenticationRequest request) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("ContentType", MediaType.APPLICATION_JSON_VALUE);
		if (null != request.getEmail() && null != request.getPassword()) {
			Account authenticatedUser = authenticationService.doLogin(request.getEmail(), request.getPassword());
			if (null != authenticatedUser) {
				LOGGER.info("User is authenticated!!");
				AuthenticationResponse authenticationResponse = new AuthenticationResponse();
				authenticationResponse.setMessage("User authentication success");
				authenticationResponse.setUser(authenticatedUser);
				return ResponseEntity.ok().headers(headers).body(authenticationResponse);
			} else {
				LOGGER.error("User Authentication failed for " + request.getEmail());
				AuthenticationResponse authenticationResponse = new AuthenticationResponse();
				authenticationResponse.setMessage("User authentication failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(authenticationResponse);
			}
		} else {
			LOGGER.error("Request is empty. Throwing validation error");
			ValidationResponse validationResponse = new ValidationResponse();
			validationResponse.setMessage("Request is invalid");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(headers).body(validationResponse);
		}
	}

	@RequestMapping(value = "/registerAlumni", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationTokenAndRegister(@RequestBody RegisterAlumni registerAlumni) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("ContentType", MediaType.APPLICATION_JSON_VALUE);
		if (null != registerAlumni.getEmail() && null != registerAlumni.getPassword()) {
			Account authenticatedUser = authenticationService.validateUserRegister(registerAlumni.getEmail());

			if (null != authenticatedUser) {
//
				LOGGER.error("User Authentication failed for " + registerAlumni.getEmail());
				AuthenticationResponse authenticationResponse = new AuthenticationResponse();
				authenticationResponse.setMessage("User authentication failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(authenticationResponse);
			} else {
				LOGGER.info("Creating a new alumni");
				User newUser = new User(registerAlumni.getFirstName(),registerAlumni.getLastName(),registerAlumni.getAddressLine1(),registerAlumni.getAddressLine2(),registerAlumni.getCity(),registerAlumni.getState(),registerAlumni.getZipcode(),registerAlumni.getContact());
				User createdparticipant = authenticationService.createAlumniUser(newUser);
				if(createdparticipant !=null) {
					int id = createdparticipant.getUserid();
					Account account = new Account(registerAlumni.getEmail(),registerAlumni.getPassword(),id,2);
					Account createaccount = authenticationService.createAlumniAccount(account);
					if(createaccount != null) {
                        AlumniObject alumniObject = new AlumniObject(createdparticipant.getUserid(),registerAlumni.getCurrentWork(),registerAlumni.getPreviousWork(),registerAlumni.getIndustry(),registerAlumni.getExperience(),Integer.parseInt(registerAlumni.getGraduationYear()));
                        AlumniObject createdAlumni = authenticationService.createAlumniObject(alumniObject);
                        if(createdAlumni !=null) {

							Account loginuser = authenticationService.doLogin(registerAlumni.getEmail(), registerAlumni.getPassword());
							if (null != loginuser) {
								LOGGER.info("User is authenticated!!");
								AuthenticationResponse authenticationResponse = new AuthenticationResponse();
								authenticationResponse.setMessage("User authentication success");
								authenticationResponse.setUser(loginuser);
								return ResponseEntity.ok().headers(headers).body(authenticationResponse);
							}

						}
                    }
				}
				ValidationResponse response = new ValidationResponse();
				response.setMessage("Follow enrollment Failure. Please try again");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} else {
			LOGGER.error("Request is empty. Throwing validation error");
			ValidationResponse validationResponse = new ValidationResponse();
			validationResponse.setMessage("Request is invalid");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(headers).body(validationResponse);
		}
	}

	@RequestMapping(value = "/registerStudent", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationTokenForStudentAndRegister(@RequestBody RegisterStudent registerStudent) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("ContentType", MediaType.APPLICATION_JSON_VALUE);
		if (null != registerStudent.getEmail() &&
				null != registerStudent.getPassword()) {
			Account authenticatedUser = authenticationService.validateUserRegister(registerStudent.getEmail());

			if (null != authenticatedUser) {
//
				LOGGER.error("User Authentication failed for " + registerStudent.getEmail());
				AuthenticationResponse authenticationResponse = new AuthenticationResponse();
				authenticationResponse.setMessage("User authentication failed");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).headers(headers).body(authenticationResponse);
			} else {
				LOGGER.info("Creating a new student");
				User newUser = new User(registerStudent.getFirstName(),registerStudent.getLastName(),registerStudent.getAddressLine1(),registerStudent.getAddressLine2(),registerStudent.getCity(),registerStudent.getState(),registerStudent.getZipcode(),registerStudent.getContact());
				User createdparticipant = authenticationService.createAlumniUser(newUser);
				if(createdparticipant !=null) {
					int id = createdparticipant.getUserid();
					Account account = new Account(registerStudent.getEmail(),registerStudent.getPassword(),id,1);
					Account createaccount = authenticationService.createAlumniAccount(account);
					if(createaccount != null) {
						StudentObject studentObject = new StudentObject(createdparticipant.getUserid(),registerStudent.getDepartment(),Integer.parseInt(registerStudent.getCurrentYear()),Integer.parseInt(registerStudent.getCreditsTillDate()),Float.valueOf(registerStudent.getGpa()),registerStudent.getStream(),registerStudent.getDegree());
						StudentObject createdStudent = authenticationService.createStudentObject(studentObject);
						if(createdStudent !=null) {

							Account loginuser = authenticationService.doLogin(registerStudent.getEmail(), registerStudent.getPassword());
							if (null != loginuser) {
								LOGGER.info("User is authenticated!!");
								AuthenticationResponse authenticationResponse = new AuthenticationResponse();
								authenticationResponse.setMessage("User authentication success");
								authenticationResponse.setUser(loginuser);
								return ResponseEntity.ok().headers(headers).body(authenticationResponse);
							}

						}
					}
				}
				ValidationResponse response = new ValidationResponse();
				response.setMessage("Follow enrollment Failure. Please try again");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			}
		} else {
			LOGGER.error("Request is empty. Throwing validation error");
			ValidationResponse validationResponse = new ValidationResponse();
			validationResponse.setMessage("Request is invalid");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(headers).body(validationResponse);
		}
	}
}
