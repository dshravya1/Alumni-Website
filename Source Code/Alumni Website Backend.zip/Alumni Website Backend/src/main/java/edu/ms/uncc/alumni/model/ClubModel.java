package edu.ms.uncc.alumni.model;

public class ClubModel {

	private int clubId;

	private String clubName;
	
	private String clubDescription;
	
	private boolean isEnrolledByTheUser;

	public int getClubId() {
		return clubId;
	}

	public void setClubId(int clubId) {
		this.clubId = clubId;
	}

	public String getClubName() {
		return clubName;
	}

	public void setClubName(String clubName) {
		this.clubName = clubName;
	}

	public String getClubDescription() {
		return clubDescription;
	}

	public void setClubDescription(String clubDescription) {
		this.clubDescription = clubDescription;
	}
	public ClubModel(Club club) {
		this.clubId = club.getClubId();
		this.clubName = club.getClubName();
		this.clubDescription = club.getClubDescription();
	}

	public boolean isEnrolledByTheUser() {
		return isEnrolledByTheUser;
	}

	public void setEnrolledByTheUser(boolean isEnrolledByTheUser) {
		this.isEnrolledByTheUser = isEnrolledByTheUser;
	}
	
}
