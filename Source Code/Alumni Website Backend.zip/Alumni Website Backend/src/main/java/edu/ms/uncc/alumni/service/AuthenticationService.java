package edu.ms.uncc.alumni.service;

import edu.ms.uncc.alumni.model.AlumniObject;
import edu.ms.uncc.alumni.model.StudentObject;
import edu.ms.uncc.alumni.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.ms.uncc.alumni.dao.AuthenticationDao;
import edu.ms.uncc.alumni.model.Account;

@Service
public class AuthenticationService {

	@Autowired
	private AuthenticationDao authenticationDao;
	
	public Account doLogin(String emailId, String password) {
		Account account = authenticationDao.getAccountByEmail(emailId);
		return account!=null ? account.getPassword().equals(password) ? account: null : null;
	}
	public Account validateUserRegister(String emailId) {
		Account account = authenticationDao.getAccountByEmail(emailId);
		return account!=null ? account: null;
	}

	public User createAlumniUser(User user){
		return authenticationDao.createAlumniUser(user);
	}

	public AlumniObject createAlumniObject(AlumniObject alumniObject){
		return authenticationDao.createAlumniObject(alumniObject);
	}

	public StudentObject createStudentObject(StudentObject studentObject){
		return authenticationDao.createStudentObject(studentObject);
	}

	public Account createAlumniAccount(Account account){
		return authenticationDao.createAlumniAccount(account);
	}
}
