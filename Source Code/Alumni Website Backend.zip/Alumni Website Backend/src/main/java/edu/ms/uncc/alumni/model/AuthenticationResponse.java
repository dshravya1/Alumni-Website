package edu.ms.uncc.alumni.model;

public class AuthenticationResponse {
	
	private Account user;
	
	public Account getUser() {
		return user;
	}


	public void setUser(Account user) {
		this.user = user;
	}

	private String message;


	public String getMessage() {
		return message;
	}

	public AuthenticationResponse(Account user) {
		this.user = user;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public AuthenticationResponse() {
		super();
	}
	
	
	
}
