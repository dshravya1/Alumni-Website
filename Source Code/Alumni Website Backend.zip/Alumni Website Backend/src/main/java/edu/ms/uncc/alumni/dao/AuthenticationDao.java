package edu.ms.uncc.alumni.dao;

import edu.ms.uncc.alumni.model.AlumniObject;
import edu.ms.uncc.alumni.model.StudentObject;
import edu.ms.uncc.alumni.model.User;
import edu.ms.uncc.alumni.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.ms.uncc.alumni.model.Account;

@Component
public class AuthenticationDao {
	
	@Autowired
	private AuthenticationRepository authenticationRepository;

	@Autowired
	private AlumniObjectRepository alumniObjectRepository;

	@Autowired
	private StudentObjectRepository studentObjectRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private AccountRepository accountRepository;
	
	public Account getAccountByEmail(String email){
		 return authenticationRepository.findOne(email);
	}

	public User createAlumniUser(User newUser){
		return userRepository.saveAndFlush(newUser);
	}
	public Account createAlumniAccount(Account account){
		return accountRepository.saveAndFlush(account);
	}

	public AlumniObject createAlumniObject(AlumniObject alumniObject) {
		return alumniObjectRepository.saveAndFlush(alumniObject);
	}
	public StudentObject createStudentObject(StudentObject studentObject) {
		return studentObjectRepository.saveAndFlush(studentObject);
	}
}
